```python
# Import libraries

import pandas as pd
import seaborn as sns
import numpy as np
pd.options.mode.chained_assignment = None  # default='warn'

pd.set_option('display.max_rows', 5)
pd.set_option('display.max_columns', 100)


import matplotlib
import matplotlib.pyplot as plt
plt.style.use('ggplot')
from matplotlib.pyplot import figure 


# Plot configuration

%matplotlib inline
matplotlib.rcParams['figure.figsize'] = (12,8) 


# Read data
df = pd.read_csv(r'C:\Users\Ethan\Documents\Portfolio\Data Projects\Python\Movie Industry\movies.csv')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>rating</th>
      <th>genre</th>
      <th>year</th>
      <th>released</th>
      <th>score</th>
      <th>votes</th>
      <th>director</th>
      <th>writer</th>
      <th>star</th>
      <th>country</th>
      <th>budget</th>
      <th>gross</th>
      <th>company</th>
      <th>runtime</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>The Shining</td>
      <td>R</td>
      <td>Drama</td>
      <td>1980</td>
      <td>June 13, 1980 (United States)</td>
      <td>8.4</td>
      <td>927000.0</td>
      <td>Stanley Kubrick</td>
      <td>Stephen King</td>
      <td>Jack Nicholson</td>
      <td>United Kingdom</td>
      <td>19000000.0</td>
      <td>46998772.0</td>
      <td>Warner Bros.</td>
      <td>146.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>The Blue Lagoon</td>
      <td>R</td>
      <td>Adventure</td>
      <td>1980</td>
      <td>July 2, 1980 (United States)</td>
      <td>5.8</td>
      <td>65000.0</td>
      <td>Randal Kleiser</td>
      <td>Henry De Vere Stacpoole</td>
      <td>Brooke Shields</td>
      <td>United States</td>
      <td>4500000.0</td>
      <td>58853106.0</td>
      <td>Columbia Pictures</td>
      <td>104.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Star Wars: Episode V - The Empire Strikes Back</td>
      <td>PG</td>
      <td>Action</td>
      <td>1980</td>
      <td>June 20, 1980 (United States)</td>
      <td>8.7</td>
      <td>1200000.0</td>
      <td>Irvin Kershner</td>
      <td>Leigh Brackett</td>
      <td>Mark Hamill</td>
      <td>United States</td>
      <td>18000000.0</td>
      <td>538375067.0</td>
      <td>Lucasfilm</td>
      <td>124.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Airplane!</td>
      <td>PG</td>
      <td>Comedy</td>
      <td>1980</td>
      <td>July 2, 1980 (United States)</td>
      <td>7.7</td>
      <td>221000.0</td>
      <td>Jim Abrahams</td>
      <td>Jim Abrahams</td>
      <td>Robert Hays</td>
      <td>United States</td>
      <td>3500000.0</td>
      <td>83453539.0</td>
      <td>Paramount Pictures</td>
      <td>88.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Caddyshack</td>
      <td>R</td>
      <td>Comedy</td>
      <td>1980</td>
      <td>July 25, 1980 (United States)</td>
      <td>7.3</td>
      <td>108000.0</td>
      <td>Harold Ramis</td>
      <td>Brian Doyle-Murray</td>
      <td>Chevy Chase</td>
      <td>United States</td>
      <td>6000000.0</td>
      <td>39846344.0</td>
      <td>Orion Pictures</td>
      <td>98.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Check for missing data 

for col in df.columns:
    percent_missing = np.mean(df[col].isnull())
    print('{} - {}%'.format(col,percent_missing))

```

    name - 0.0%
    rating - 0.010041731872717789%
    genre - 0.0%
    year - 0.0%
    released - 0.0002608242044861763%
    score - 0.0003912363067292645%
    votes - 0.0003912363067292645%
    director - 0.0%
    writer - 0.0003912363067292645%
    star - 0.00013041210224308815%
    country - 0.0003912363067292645%
    budget - 0.2831246739697444%
    gross - 0.02464788732394366%
    company - 0.002217005738132499%
    runtime - 0.0005216484089723526%
    


```python
# Drop rows with null values

df = df.dropna(how='any',axis=0)
```


```python
# Data types

df.dtypes
```




    name         object
    rating       object
    genre        object
    year          int64
    released     object
    score       float64
    votes       float64
    director     object
    writer       object
    star         object
    country      object
    budget      float64
    gross       float64
    company      object
    runtime     float64
    dtype: object




```python
# Change data type

df['budget'] = df['budget'].astype('int64')

df['gross'] = df['gross'].astype('int64')
```


```python
# Get year from release date by splttiing on delimters

new = df['released'].str.split(',',expand=True)

new = new[1].dropna(how='any',axis = 0)

new = new.str.split('(',expand= True)

new = new[0]

# Remove white spaces 

new = new.str.replace(" ","")

# Add year to main df

df['yearcorrect'] = new
```


```python
# Order by gross value descending
df.sort_values(by=['gross'], inplace = False, ascending= False).head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>rating</th>
      <th>genre</th>
      <th>year</th>
      <th>released</th>
      <th>score</th>
      <th>votes</th>
      <th>director</th>
      <th>writer</th>
      <th>star</th>
      <th>country</th>
      <th>budget</th>
      <th>gross</th>
      <th>company</th>
      <th>runtime</th>
      <th>yearcorrect</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5445</th>
      <td>386</td>
      <td>5</td>
      <td>0</td>
      <td>2009</td>
      <td>527</td>
      <td>7.8</td>
      <td>1100000.0</td>
      <td>785</td>
      <td>1263</td>
      <td>1534</td>
      <td>47</td>
      <td>237000000</td>
      <td>2847246203</td>
      <td>1382</td>
      <td>162.0</td>
      <td>29</td>
    </tr>
    <tr>
      <th>7445</th>
      <td>388</td>
      <td>5</td>
      <td>0</td>
      <td>2019</td>
      <td>137</td>
      <td>8.4</td>
      <td>903000.0</td>
      <td>105</td>
      <td>513</td>
      <td>1470</td>
      <td>47</td>
      <td>356000000</td>
      <td>2797501328</td>
      <td>983</td>
      <td>181.0</td>
      <td>39</td>
    </tr>
    <tr>
      <th>3045</th>
      <td>4909</td>
      <td>5</td>
      <td>6</td>
      <td>1997</td>
      <td>534</td>
      <td>7.8</td>
      <td>1100000.0</td>
      <td>785</td>
      <td>1263</td>
      <td>1073</td>
      <td>47</td>
      <td>200000000</td>
      <td>2201647264</td>
      <td>1382</td>
      <td>194.0</td>
      <td>17</td>
    </tr>
    <tr>
      <th>6663</th>
      <td>3643</td>
      <td>5</td>
      <td>0</td>
      <td>2015</td>
      <td>529</td>
      <td>7.8</td>
      <td>876000.0</td>
      <td>768</td>
      <td>1806</td>
      <td>356</td>
      <td>47</td>
      <td>245000000</td>
      <td>2069521700</td>
      <td>945</td>
      <td>138.0</td>
      <td>35</td>
    </tr>
    <tr>
      <th>7244</th>
      <td>389</td>
      <td>5</td>
      <td>0</td>
      <td>2018</td>
      <td>145</td>
      <td>8.4</td>
      <td>897000.0</td>
      <td>105</td>
      <td>513</td>
      <td>1470</td>
      <td>47</td>
      <td>321000000</td>
      <td>2048359754</td>
      <td>983</td>
      <td>149.0</td>
      <td>38</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Drop any dubplicates 

df = df.drop_duplicates()
```


```python
# Finding correlation between budget and gross


# Scatter plot ( budget vs gross )

plt.scatter(x=df['budget'],y=df['gross'])

plt.title('Budget vs Gross Earnings')
plt.xlabel('Budget')
plt.ylabel('Gross Earnings')

plt.show()
```


    
![png](output_9_0.png)
    



```python
# Plot budget vs gross using Seaborn


sns.regplot(x='budget',y='gross', data = df, scatter_kws={"color":"red"}, line_kws={"color":"blue"})
```




    <Axes: xlabel='budget', ylabel='gross'>




    
![png](output_10_1.png)
    



```python
# Correlation values
# Pearson, Kendall, Spearman

print("Pearson")
print(df.corr(method='pearson'))
print()

print("Kendall")
print(df.corr(method='kendall'))
print()

print("Spearman")
print(df.corr(method='spearman'))
print()

```

    Pearson
                 year     score     votes    budget     gross   runtime
    year     1.000000  0.056386  0.206021  0.327722  0.274321  0.075077
    score    0.056386  1.000000  0.474256  0.072001  0.222556  0.414068
    votes    0.206021  0.474256  1.000000  0.439675  0.614751  0.352303
    budget   0.327722  0.072001  0.439675  1.000000  0.740247  0.318695
    gross    0.274321  0.222556  0.614751  0.740247  1.000000  0.275796
    runtime  0.075077  0.414068  0.352303  0.318695  0.275796  1.000000
    
    Kendall
                 year     score     votes    budget     gross   runtime
    year     1.000000  0.039389  0.296512  0.220833  0.239539  0.064824
    score    0.039389  1.000000  0.350185 -0.006406  0.124943  0.292254
    votes    0.296512  0.350185  1.000000  0.346274  0.553625  0.205344
    budget   0.220833 -0.006406  0.346274  1.000000  0.512057  0.231278
    gross    0.239539  0.124943  0.553625  0.512057  1.000000  0.176979
    runtime  0.064824  0.292254  0.205344  0.231278  0.176979  1.000000
    
    Spearman
                 year     score     votes    budget     gross   runtime
    year     1.000000  0.057741  0.427623  0.312886  0.351045  0.095444
    score    0.057741  1.000000  0.495409 -0.009971  0.183192  0.412155
    votes    0.427623  0.495409  1.000000  0.493461  0.745793  0.300621
    budget   0.312886 -0.009971  0.493461  1.000000  0.692958  0.330794
    gross    0.351045  0.183192  0.745793  0.692958  1.000000  0.257400
    runtime  0.095444  0.412155  0.300621  0.330794  0.257400  1.000000
    
    

    C:\Users\Ethan\AppData\Local\Temp\ipykernel_6988\3461148744.py:5: FutureWarning: The default value of numeric_only in DataFrame.corr is deprecated. In a future version, it will default to False. Select only valid columns or specify the value of numeric_only to silence this warning.
      print(df.corr(method='pearson'))
    C:\Users\Ethan\AppData\Local\Temp\ipykernel_6988\3461148744.py:9: FutureWarning: The default value of numeric_only in DataFrame.corr is deprecated. In a future version, it will default to False. Select only valid columns or specify the value of numeric_only to silence this warning.
      print(df.corr(method='kendall'))
    C:\Users\Ethan\AppData\Local\Temp\ipykernel_6988\3461148744.py:13: FutureWarning: The default value of numeric_only in DataFrame.corr is deprecated. In a future version, it will default to False. Select only valid columns or specify the value of numeric_only to silence this warning.
      print(df.corr(method='spearman'))
    


```python
corr_matrix = df.corr(method='pearson')

sns.heatmap(corr_matrix, annot=True)

plt.title('Correlation Matrix for Numeric Features')
plt.xlabel('Movie Features')
plt.ylabel('Movie Features')

plt.show()


```

    C:\Users\Ethan\AppData\Local\Temp\ipykernel_6988\3420613217.py:1: FutureWarning: The default value of numeric_only in DataFrame.corr is deprecated. In a future version, it will default to False. Select only valid columns or specify the value of numeric_only to silence this warning.
      corr_matrix = df.corr(method='pearson')
    


    
![png](output_12_1.png)
    



```python
# Taking company into consideration 

df_numerized = df 

for col in df_numerized.columns:
    if (df_numerized[col].dtype == 'object'):
        df_numerized[col]= df_numerized[col].astype('category')
        df_numerized[col]= df_numerized[col].cat.codes
        
```


```python
# Heatmap based on Company

corr_matrix = df_numerized.corr(method='pearson')

sns.heatmap(corr_matrix, annot=True)

plt.title('Correlation Matrix for Numeric Features')
plt.xlabel('Movie Features')
plt.ylabel('Movie Features')

plt.show()
```


    
![png](output_14_0.png)
    



```python
correlation_maxtrix = df_numerized.corr(method='pearson')

corr_pairs = correlation_maxtrix.unstack()

sorted_pairs = corr_pairs.sort_values()

high_corr = sorted_pairs[(sorted_pairs)> 0.5]
```


```python
high_corr
```




    votes        gross          0.614751
    gross        votes          0.614751
                 budget         0.740247
    budget       gross          0.740247
    yearcorrect  year           0.996723
    year         yearcorrect    0.996723
    name         name           1.000000
    company      company        1.000000
    gross        gross          1.000000
    budget       budget         1.000000
    country      country        1.000000
    star         star           1.000000
    writer       writer         1.000000
    director     director       1.000000
    votes        votes          1.000000
    score        score          1.000000
    released     released       1.000000
    year         year           1.000000
    genre        genre          1.000000
    rating       rating         1.000000
    runtime      runtime        1.000000
    yearcorrect  yearcorrect    1.000000
    dtype: float64




```python

```
